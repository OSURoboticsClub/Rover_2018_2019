

class WindTemp {
	public:
		WindTemp();
		WindTemp(int,int);
		void update(float&,float&);
		
	private:
		
		int wndData[25];
		int tmpData[10];
		
		float Wscale;
		float Woffset;
		float Tscale;
		float Toffset;
		
		float convert_to_voltage(int);
		float average(int*,int,int);
		int windPin;
		int tempPin;
};

WindTemp::WindTemp(){
	//TdataSize = 10;
	//WdataSize = 25;
	Wscale = 14.7;
	Woffset = -22;
	Tscale = 59;
	Toffset = -31;
	tempPin = A9;
	windPin = A8;
}

WindTemp::WindTemp(int w,int t){
	Wscale = 14.7;
	Woffset = -22;
	Tscale = 59;
	Toffset = -31;
	tempPin = t;
	windPin = w;
}

float WindTemp::average(int* ar,int in,int dataSize){
  int temp[dataSize];
  for(int i = 1;i<dataSize;i++)
    temp[i-1] = ar[i];  
  temp[dataSize-1] = in;
  int sum =0;
  for(int i=0;i<dataSize;i++){
    sum += temp[i];
    ar[i] = temp[i];
  }
  return float(sum)/dataSize;
}

float WindTemp::convert_to_voltage(int in){
  return in*(3.3/1024); 
}

void WindTemp::update(float& windS, float& tempS){
	int temp = average(tmpData,analogRead(tempPin),10);
	int wind = average(wndData,analogRead(windPin),25);

	float tempV = convert_to_voltage(temp);
	float windV = convert_to_voltage(wind);

	windS = windV*Wscale + Woffset;
	tempS = tempV*Tscale + Toffset;
}

